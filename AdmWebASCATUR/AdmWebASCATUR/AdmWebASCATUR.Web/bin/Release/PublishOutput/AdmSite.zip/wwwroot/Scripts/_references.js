﻿/// <reference path="jquery-ui-1.12.1.js" />
/// <reference path="jquery-3.1.1.js" />
/// <autosync enabled="false" />
/// <reference path="serenity/Serenity.CoreLib.js" />
/// <reference path="serenity/Serenity.Script.UI.js" />
/// <reference path="site/AdmWebASCATUR.Web.js" />
