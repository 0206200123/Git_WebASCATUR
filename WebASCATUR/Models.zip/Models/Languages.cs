﻿using System;
using System.Collections.Generic;

namespace WebASCATUR.Models
{
    public partial class Languages
    {
        public int Id { get; set; }
        public string LanguageId { get; set; }
        public string LanguageName { get; set; }
    }
}
